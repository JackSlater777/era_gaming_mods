Для корректной работы мода нужны:
- Wog Fix Lite
- Game Enhancement Mod
